package com.SpringTimeTask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;



/**
 * Spring定时任务
 *
 */
@SpringBootApplication
@EnableScheduling
//@EnableScheduling发现注解@Scheduled的任务并后台执行
public class App 
{
    public static void main( String[] args )
    {
    	SpringApplication.run(App.class, args);
    	System.out.println("启动成功！");
    	
    }
}
